use thanatos::real_main;

/// Entrypoint when running the binary standalone.
fn main() {
    real_main().unwrap();
}
